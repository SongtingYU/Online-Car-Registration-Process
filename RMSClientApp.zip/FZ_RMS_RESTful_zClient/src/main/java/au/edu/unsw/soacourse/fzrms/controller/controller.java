package au.edu.unsw.soacourse.fzrms.controller;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.cxf.jaxrs.client.WebClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import au.edu.unsw.soacourse.fzrms.model.*;
import au.edu.unsw.soacourse.fzrms.util.*;

@Controller
public class controller {

	private String REST_URI = "http://localhost:8080/FZ_RMS_RESTful_Services";
	private WebClient client = WebClient.create(REST_URI);
	private String SecurityKey = "abc-123-cty";

	@RequestMapping("")
	public ModelAndView welcomepage(
			@RequestParam(value = "userType", required = false, defaultValue = "0") String userType,
			HttpServletRequest request) throws Exception {
		ModelAndView mv = new ModelAndView("welcome");
		if (userType.equals("1")) {
			mv = new ModelAndView("driver");
		}
		if (userType.equals("2")) {
			mv = new ModelAndView("officer");
		}

		return mv;
	}

	@RequestMapping("/driver")
	public ModelAndView driverpage(
			@RequestParam(value = "target", required = false, defaultValue = "0") String target,
			@RequestParam(value = "opera", required = false, defaultValue = "0") String opera,
			HttpServletRequest request) throws Exception {
		ModelAndView mv = new ModelAndView("driver");
		if (opera.equals("0")) {
			if (!target.equals("0")) {
				mv.addObject("target", 1);
				client.reset();
				client.path("/Notices/" + target).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				NoticeBean notice = client.get(NoticeBean.class);
				client.reset();
				client.path("/Registrations/" + notice.get_rid()).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				EntryBean entry = client.get(EntryBean.class);
				mv.addObject("notice", notice);
				mv.addObject("entry", entry);
			}
		}
		if (opera.equals("1")) {
			String action = request.getParameter("action");
			if (action.equals("Confirm Renew")) {
				mv = new ModelAndView("driver_update_result");
				String _nid = request.getParameter("_nid");
				EntryBean updateEntry = new EntryBean();
				updateEntry.set_rid(request.getParameter("_rid"));
				updateEntry.setregistrationNumber(request
						.getParameter("registrationNumber"));
				DriverBean driver = new DriverBean();
				driver.setlastName(request.getParameter("last_name"));
				driver.setfirstName(request.getParameter("first_name"));
				driver.setdriversLicenseNo(request
						.getParameter("driversLicenseNo"));
				driver.setaddress(request.getParameter("address"));
				driver.setemail(request.getParameter("email"));
				updateEntry.setDriver(driver);
				updateEntry.setregistrationValidTill(request
						.getParameter("ValidTill"));
				client.reset();
				client.path("/Notices/driver/" + _nid).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				Response res = client.put(updateEntry);
				mv.addObject("status", res.getStatus());
			}
			if (action.equals("Cancel Renew")) {
				mv = new ModelAndView("driver_cancel");
				String _nid = request.getParameter("_nid");
				client.reset();
				client.path("/Notices/cancelled/" + _nid).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				Response res = client.delete();
				mv.addObject("status", res.getStatus());
			}
		}
		if (opera.equals("2")) {
			mv = new ModelAndView("driver_check_status");
			client.reset();
			client.path("/Notices/" + target).accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			NoticeBean notice = client.get(NoticeBean.class);
			client.reset();
			client.path("/Registrations/" + notice.get_rid()).accept(
					MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			EntryBean tmpEntry = client.get(EntryBean.class);
			mv.addObject("notice", notice);
			mv.addObject("entry", tmpEntry);
		}
		if (opera.equals("3")) {
			mv = new ModelAndView("driver_payment");
			client.reset();
			client.path("/Payments/" + target)
					.accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			PaymentBean payment = client.get(PaymentBean.class);
			mv.addObject("payment", payment);
		}
		if (opera.equals("4")) {
			mv = new ModelAndView("driver_payment_result");
			PaymentBean payment = new PaymentBean();
			payment.set_pid(request.getParameter("_pid"));
			payment.setCredit_card_details(request
					.getParameter("credit_card_details"));
			client.reset();
			client.path("/Payments").accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			Response res = client.put(payment);
			int status = res.getStatus();
			mv.addObject("status", status);
			if (status == 200) {
				client.reset();
				client.path("/Notices/archived/" + request.getParameter("_nid"))
						.accept(MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				res = client.delete();
			}
		}
		return mv;
	}

	@RequestMapping("/officer")
	public ModelAndView officerpage(
			@RequestParam(value = "opera", required = false, defaultValue = "0") String opera,
			@RequestParam(value = "target", required = false, defaultValue = "0") String target,
			@RequestParam(value = "action", required = false, defaultValue = "0") String action,
			HttpServletRequest request) throws Exception {
		ModelAndView mv = new ModelAndView("officer");
		if (opera.equals("1")) {
			mv = new ModelAndView("officer_generate_notices");
			client.reset();
			client.path("/Notices").accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			Object tmpObject = null;
			Response response = client.post(tmpObject);
			int status = response.getStatus();
			mv.addObject("status", status);
			if (status == 200) {
				client.reset();
				client.path("/Notices").accept(MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				NoticesList nl = client.get(NoticesList.class);
				List<NoticeBean> noticesList = new ArrayList<NoticeBean>();
				noticesList = nl.getList();
				List<EntryBean> entrysList = new ArrayList<EntryBean>();
				for (NoticeBean n : nl.getList()) {
					client.reset();
					client.path("/Registrations/" + n.get_rid()).accept(
							MediaType.APPLICATION_XML);
					client.header("SecurityKey", SecurityKey);
					EntryBean tmpEntry = client.get(EntryBean.class);
					entrysList.add(tmpEntry);
					String uri1 = "http://localhost:8080/FZ_RMS_RESTful_zClient/driver?target="
							+ n.get_nid();
					String uri2 = "http://localhost:8080/FZ_RMS_RESTful_zClient/driver?opera=2&target="
							+ n.get_nid();
					// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
					EmailUtil.sendAlert(tmpEntry.getDriver().getemail(),
							tmpEntry.getDriver().getfirstName(), uri1, uri2);
					// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
				}
				mv.addObject("noticesList", noticesList);
				mv.addObject("entrysList", entrysList);
			}
		}
		if (opera.equals("2")) {
			mv = new ModelAndView("all_notices");
			client.reset();
			client.path("/Notices").accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			NoticesList nl = client.get(NoticesList.class);
			List<NoticeBean> noticesList = new ArrayList<NoticeBean>();
			noticesList = nl.getList();
			List<EntryBean> entrysList = new ArrayList<EntryBean>();
			for (NoticeBean n : nl.getList()) {
				client.reset();
				client.path("/Registrations/" + n.get_rid()).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				EntryBean tmpEntry = client.get(EntryBean.class);
				entrysList.add(tmpEntry);
			}
			mv.addObject("noticesList", noticesList);
			mv.addObject("entrysList", entrysList);
		}
		if (opera.equals("3")) {
			mv = new ModelAndView("address_check");
			client.reset();
			client.path("/Notices").accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			NoticesList nl = client.get(NoticesList.class);
			List<NoticeBean> checkList = new ArrayList<NoticeBean>();
			for (NoticeBean tmp : nl.getList()) {
				if (tmp.getStatus().equals("requested")
						|| tmp.getStatus().equals("under-review")) {
					client.reset();
					client.path("/Notices/officer/" + tmp.get_nid()).accept(
							MediaType.APPLICATION_XML);
					client.header("SecurityKey", SecurityKey);
					Response res = client.put("under-review");
					if (res.getStatus() == 200) {
						tmp.setStatus("under-review");
						checkList.add(tmp);
					}
				}
			}
			Map<String, String> checkMap = new HashMap<String, String>();
			List<EntryBean> entrysList = new ArrayList<EntryBean>();
			for (NoticeBean tmp : checkList) {
				client.reset();
				client.path("/Registrations/" + tmp.get_rid()).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				EntryBean tmpEntry = client.get(EntryBean.class);
				entrysList.add(tmpEntry);
				if (BPEL_Address_Auto_Check(tmpEntry.getDriver().getaddress())) {
					checkMap.put(tmpEntry.get_rid(), "Passed");
				} else {
					checkMap.put(tmpEntry.get_rid(), "Invalid");
				}
			}
			mv.addObject("noticesList", checkList);
			mv.addObject("entrysList", entrysList);
			mv.addObject("checkMap", checkMap);
		}
		if (opera.equals("4")) {
			client.reset();
			client.path("/Notices/" + target).accept(MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			NoticeBean notice = client.get(NoticeBean.class);
			client.reset();
			client.path("/Registrations/" + notice.get_rid()).accept(
					MediaType.APPLICATION_XML);
			client.header("SecurityKey", SecurityKey);
			EntryBean entry = client.get(EntryBean.class);
			String email = entry.getDriver().getemail();
			String name = entry.getDriver().getfirstName();
			String uri2 = "http://localhost:8080/FZ_RMS_RESTful_zClient/driver?opera=2&target="
					+ notice.get_nid();

			if (action.equals("Rejected")) {
				mv = new ModelAndView("officer_rejected");
				client.reset();
				client.path("/Notices/officer/" + target).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				Response res = client.put("rejected");
				String uri1 = "http://localhost:8080/FZ_RMS_RESTful_zClient/driver?target="
						+ notice.get_nid();
				EmailUtil.sendRejected(email, name, uri1, uri2);
				mv.addObject("status", res.getStatus());
				mv.addObject("uri", uri1);
			}
			if (action.equals("Accepted")) {
				mv = new ModelAndView("officer_accepted");
				client.reset();
				client.path("/Notices/officer/" + target).accept(
						MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				Response res = client.put("accepted");
				mv.addObject("status", res.getStatus());
				mv.addObject("target", target);
			}
			if (action.equals("amount")) {
				mv = new ModelAndView("officer_accepted_payment");
				String amount = request.getParameter("amount");
				PaymentBean payment = new PaymentBean();
				payment.set_pid("");
				payment.set_nid(target);
				payment.setAmount(amount);
				payment.setCredit_card_details("");
				payment.setPaid_date("");
				client.reset();
				client.path("/Payments").accept(MediaType.APPLICATION_XML);
				client.header("SecurityKey", SecurityKey);
				Response res = client.post(payment);
				int status = res.getStatus();
				mv.addObject("status", status);
				if (status == 200) {
					client.reset();
					client.path("/Payments/getlast").accept(
							MediaType.APPLICATION_XML);
					client.header("SecurityKey", SecurityKey);
					payment = client.get(PaymentBean.class);
					String _pid = payment.get_pid();
					String uri1 = "http://localhost:8080/FZ_RMS_RESTful_zClient/driver?opera=3&target="
							+ _pid;
					mv.addObject("uri", uri1);
					EmailUtil.sendPayment(email, name, uri1, uri2);
				} else {
					client.reset();
					client.path("/Notices/officer/" + target).accept(
							MediaType.APPLICATION_XML);
					client.header("SecurityKey", SecurityKey);
					res = client.put("under-review");
				}
			}
		}
		return mv;
	}

	private boolean BPEL_Address_Auto_Check(String address) {
		try {
			// Create SOAP Connection
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory
					.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory
					.createConnection();
			// Send SOAP Message to SOAP Server
			String url = "http://localhost:6060/ode/processes/AddressCheck";
			MessageFactory messageFactory = MessageFactory.newInstance();
			SOAPMessage soapMessage = messageFactory.createMessage();
			SOAPPart soapPart = soapMessage.getSOAPPart();

			String serverURI = "http://gnafaddressservice.soacourse.unsw.edu.au/addresscheck";
			SOAPEnvelope envelope = soapPart.getEnvelope();
			envelope.addNamespaceDeclaration("q0", serverURI);
			SOAPBody soapBody = envelope.getBody();
			SOAPElement soapBodyElem = soapBody.addChildElement(
					"AddressCheckRequest", "q0");
			SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("address",
					"q0");
			soapBodyElem1.addTextNode(address);

			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", serverURI);
			soapMessage.saveChanges();
			SOAPMessage soapResponse = soapConnection.call(soapMessage, url);
			// Process the SOAP Response
			TransformerFactory transformerFactory = TransformerFactory
					.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			Source sourceContent = soapResponse.getSOAPPart().getContent();
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			transformer.transform(sourceContent, result);

			// System.out.println(sw.toString());

			if (sw.toString().contains(">Exact Address Found<"))
				return true;
			soapConnection.close();
		} catch (Exception e) {
			System.err
					.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		}
		return false;
	}
}
