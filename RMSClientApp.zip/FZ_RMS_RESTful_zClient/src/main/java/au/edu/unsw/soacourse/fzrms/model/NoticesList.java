package au.edu.unsw.soacourse.fzrms.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "notices")
@XmlAccessorType(XmlAccessType.FIELD)
public class NoticesList {

	@XmlElement(name = "notice")
	private List<NoticeBean> list = new ArrayList<NoticeBean>();

	public NoticesList() {
		super();
	}

	public NoticesList(List<NoticeBean> list) {
		super();
		this.list = list;
	}

	public List<NoticeBean> getList() {
		return list;
	}

	public void setList(List<NoticeBean> list) {
		this.list = list;
	}

	public NoticeBean getNotice(String _nid) {
		for (NoticeBean n : list)
			if (n.get_nid().equals(_nid))
				return n;
		return null;
	}

	public int getCount() {
		return list.size();
	}
}
