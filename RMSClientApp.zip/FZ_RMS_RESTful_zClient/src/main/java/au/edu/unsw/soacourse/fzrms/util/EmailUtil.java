package au.edu.unsw.soacourse.fzrms.util;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

public class EmailUtil {
	
	private static String myUserName = "rms.renewalonline@yahoo.com";
	private static String Password = "RMS.password";
	private static String HostName = "smtp.mail.yahoo.com";

	public static void sendAlert(String email_add, String name, String uri1, String uri2) {
		SimpleEmail email = new SimpleEmail();
//		String myUserName = "rms_renewal_online@163.com";
//		String Password = "RMSpassword123";

//		String myUserName = "rms.renewalonline@yahoo.com";
//		String Password = "RMS.password";
		
		// String sendTo = Email;
		StringBuffer sb = new StringBuffer(
				"The mail is from RMS Renewal Online System, ");
		sb.append("please click the URL to complete renewal\n\n");
		sb.append("Dear " + name + ",\n\n");
		sb.append("Thank you for using RMS Renewal Online System, please click the URL below to complete your renewal:\n");
		sb.append(uri1);
		sb.append("\n\n");
		sb.append("You can use the link below to check the process status at any time:\n");
		sb.append(uri2);
		sb.append("\n\n");
		sb.append("Yours sincerely.\n\n");
		sb.append("Please do not reply.\n");
		sb.append("RMS Renewal Online System.\n\n");
		try {
			email.setHostName(HostName);

			email.setAuthentication(myUserName, Password);
			email.setSSLOnConnect(true);
			email.setFrom(myUserName);
			email.setSubject("Renewal Notices");

			String s = sb.toString();
			email.setMsg(s);
			email.addTo(email_add);
			email.send();
		} catch (EmailException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

	}
	
	public static void sendRejected(String email_add, String name, String uri1, String uri2) {
		SimpleEmail email = new SimpleEmail();
//		String myUserName = "rms_renewal_online@163.com";
//		String Password = "RMSpassword123";

		// String sendTo = Email;
		StringBuffer sb = new StringBuffer(
				"The mail is from RMS Renewal Online System, ");
		sb.append("please click the URL to complete renewal\n\n");
		sb.append("Dear " + name + ",\n\n");
		sb.append("Thank you for using RMS Renewal Online System, your renewal has been rejected, need to re-request by the link below:\n");
		sb.append(uri1);
		sb.append("\n\n");
		sb.append("You can use the link below to check the process status at any time:\n");
		sb.append(uri2);
		sb.append("\n\n");
		sb.append("Yours sincerely.\n\n");
		sb.append("Please do not reply.\n");
		sb.append("RMS Renewal Online System.\n\n");
		try {
			email.setHostName(HostName);

			email.setAuthentication(myUserName, Password);
			email.setSSLOnConnect(true);
			email.setFrom(myUserName);
			email.setSubject("Renewal Notices");

			String s = sb.toString();
			email.setMsg(s);
			email.addTo(email_add);
			email.send();
		} catch (EmailException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

	}
	
	public static void sendPayment(String email_add, String name, String uri1, String uri2) {
		SimpleEmail email = new SimpleEmail();
//		String myUserName = "rms_renewal_online@163.com";
//		String Password = "RMSpassword123";

		// String sendTo = Email;
		StringBuffer sb = new StringBuffer(
				"The mail is from RMS Renewal Online System, ");
		sb.append("please click the URL to complete renewal\n\n");
		sb.append("Dear " + name + ",\n\n");
		sb.append("Thank you for using RMS Renewal Online System, your renewal has been accepted, please complate payment info by click link below:\n");
		sb.append(uri1);
		sb.append("\n\n");
		sb.append("You can use the link below to check the process status in any time:\n");
		sb.append(uri2);
		sb.append("\n\n");
		sb.append("Yours sincerely.\n\n");
		sb.append("Please do not reply.\n");
		sb.append("RMS Renewal Online System.\n\n");
		try {
			email.setHostName(HostName);

			email.setAuthentication(myUserName, Password);
			email.setSSLOnConnect(true);
			email.setFrom(myUserName);
			email.setSubject("Renewal Notices");

			String s = sb.toString();
			email.setMsg(s);
			email.addTo(email_add);
			email.send();
		} catch (EmailException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

	}
}
