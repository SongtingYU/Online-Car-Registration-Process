package au.edu.unsw.soacourse.FZ_RESTful_Services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.DB_PaymentsDao;
import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.DB_RenewalNoticesDao;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.EntryBean;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.DB_PaymentBean;

@Path("/DBPayment")
public class DB_PaymentsResource {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;
	
	@GET
	@Path("/{_pid}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public DB_PaymentBean getPayment(@PathParam("_pid") String _pid) {
		DB_PaymentBean e = DB_PaymentsDao.instance.getPayment(_pid);
		if (e == null)
			return null;
		return e;
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	public Response updatePayment(DB_PaymentBean payment) {
		Response res;
		if (DB_PaymentsDao.instance.updatePayment(payment)) {
			Object entity = (Object) "update";
			res = Response.ok(entity).build();
		} else {
			Object entity = (Object) "updateERROR";
			res = Response.ok(entity).build();
		}
		return res;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	public Response createPayment(DB_PaymentBean payment) {
		Response res;
		String uri = DB_PaymentsDao.instance.createPayment(payment);
		if (uri != null) {
			Object entity = (Object) "createPaymentSuccess\n";
			entity += "amount: " + payment.getAmount() + "\n";	
			entity += uri + "\n";	
			res = Response.ok(entity).build();
		} else {
			Object entity = (Object) "NoNoticeNeed";
			res = Response.ok(entity).build();
		}
		return res;
	}	
}
