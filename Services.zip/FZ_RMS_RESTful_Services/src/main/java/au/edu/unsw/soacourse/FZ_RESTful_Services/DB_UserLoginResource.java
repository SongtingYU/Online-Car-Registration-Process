package au.edu.unsw.soacourse.FZ_RESTful_Services;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.DB_UserLoginDao;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.EntryBean;

@Path("/UserLogin")
public class DB_UserLoginResource {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;

	@GET
	@Path("/_rid/{_rid}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public EntryBean getEntry(@PathParam("_rid") String _rid) {
		EntryBean e = DB_UserLoginDao.instance.queryEntry(_rid);
		if (e == null)
			return null;
		return e;
	}


}
