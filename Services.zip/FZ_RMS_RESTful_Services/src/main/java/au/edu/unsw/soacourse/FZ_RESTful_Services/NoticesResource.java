package au.edu.unsw.soacourse.FZ_RESTful_Services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.*;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.*;

@Path("/Notices")
public class NoticesResource {
	@Context
	UriInfo uriInfo;
	@Context
	Request request;
	private String securityKey = "abc-123-cty";

	@POST
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<NoticeBean> GenerateRenewalNotices(
			@HeaderParam("SecurityKey") String securityKey) {
		if (!this.securityKey.equals(securityKey))
			return null;
		List<NoticeBean> n = NoticesDao.instance.generateNotices();
		if (n.size() > 0) {
			return n;
		}
		return null;
	}

	@GET
	@Path("/{_nid}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public NoticeBean getNotice(@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_nid") String _nid) {
		if (!this.securityKey.equals(securityKey))
			return null;
		NoticeBean n = NoticesDao.instance.getNotice(_nid);
		if (n == null)
			return null;
		return n;
	}

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<NoticeBean> getAllNotices(
			@HeaderParam("SecurityKey") String securityKey) {
		if (!this.securityKey.equals(securityKey))
			return null;
		List<NoticeBean> n = NoticesDao.instance.getAllNotices();
		if (n == null)
			return null;
		return n;
	}

	@PUT
	@Path("/driver/{_nid}")
	@Consumes(MediaType.APPLICATION_XML)
	public Response updateDriver(
			@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_nid") String _nid, EntryBean entry) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		if (NoticesDao.instance.updateDriver(_nid, entry)) {
			Object entity = (Object) "update";
			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}

	@PUT
	@Path("/officer/{_nid}")
	@Consumes(MediaType.APPLICATION_XML)
	public Response updateOfficer(
			@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_nid") String _nid, String status) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		if (NoticesDao.instance.updateOfficer(_nid, status)) {
			Object entity = (Object) "update";
			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}

	@DELETE
	@Path("/cancelled/{_nid}")
	public Response CancelledRequest(
			@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_nid") String _nid) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		if (NoticesDao.instance.CancelledRequest(_nid)) {
			Object entity = (Object) "cancelled";
			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}

	@DELETE
	@Path("/archived/{_nid}")
	public Response ArchivedRequest(
			@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_nid") String _nid) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		if (NoticesDao.instance.ArchivedRequest(_nid)) {
			Object entity = (Object) "archived";
			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}
}
