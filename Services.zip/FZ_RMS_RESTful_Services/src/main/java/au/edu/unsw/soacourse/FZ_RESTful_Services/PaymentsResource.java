package au.edu.unsw.soacourse.FZ_RESTful_Services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.*;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.*;

@Path("/Payments")
public class PaymentsResource {
	@Context
	UriInfo uriInfo;
	@Context
	Request request;
	private String securityKey = "abc-123-cty";

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<PaymentBean> getAllPayments(
			@HeaderParam("SecurityKey") String securityKey) {
		if (!this.securityKey.equals(securityKey))
			return null;
		List<PaymentBean> p = PaymentsDao.instance.getAllPayments();
		if (p == null)
			return null;
		return p;
	}

	@GET
	@Path("/{_pid}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PaymentBean getPayment(
			@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_pid") String _pid) {
		if (!this.securityKey.equals(securityKey))
			return null;
		PaymentBean p = PaymentsDao.instance.getPayment(_pid);
		if (p == null)
			return null;
		return p;
	}

	@GET
	@Path("/getlast")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public PaymentBean getLastPayment(
			@HeaderParam("SecurityKey") String securityKey) {
		if (!this.securityKey.equals(securityKey))
			return null;
		PaymentBean p = PaymentsDao.instance.getPayment(PaymentsDao.instance
				.last_pid());
		System.out.println(p);
		if (p == null)
			return null;
		return p;
	}

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	public Response setPayment(@HeaderParam("SecurityKey") String securityKey,
			PaymentBean payment) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		String _pid = PaymentsDao.instance.insertPayment(payment);
		if (!_pid.equals("000")) {

			Object entity = (Object) "SetPaymentSuccess\n";

			entity += _pid + "\n";

			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}

	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	public Response updatePayment(
			@HeaderParam("SecurityKey") String securityKey, PaymentBean payment) {
		if (!this.securityKey.equals(securityKey))
			return null;
		Response res;
		String _pid = PaymentsDao.instance.updatePayment(payment);
		if (!_pid.isEmpty()) {
			Object entity = (Object) "update";
			res = Response.ok(entity).build();
		} else {
			res = Response.notModified().build();
		}
		return res;
	}
}
