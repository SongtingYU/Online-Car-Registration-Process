package au.edu.unsw.soacourse.FZ_RESTful_Services;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import au.edu.unsw.soacourse.FZ_RESTful_Services.dao.RegistrationsDao;
import au.edu.unsw.soacourse.FZ_RESTful_Services.model.EntryBean;

@Path("/Registrations")
public class RegistrationsResource {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;
	private String securityKey = "abc-123-cty";

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<EntryBean> getRegistrations(
			@HeaderParam("SecurityKey") String securityKey) {
		if (!this.securityKey.equals(securityKey))
			return null;
		List<EntryBean> results = RegistrationsDao.instance.getRegistrations();
		if (results.size() == 0)
			return null;
		return results;
	}

	@GET
	@Path("{_rid}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public EntryBean getEntry(@HeaderParam("SecurityKey") String securityKey,
			@PathParam("_rid") String _rid) {
		if (!this.securityKey.equals(securityKey))
			return null;
		EntryBean e = RegistrationsDao.instance.queryEntry(_rid);
		if (e == null)
			return null;
		return e;
	}

}
