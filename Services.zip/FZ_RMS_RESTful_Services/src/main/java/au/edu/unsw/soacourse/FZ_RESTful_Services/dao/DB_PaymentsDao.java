package au.edu.unsw.soacourse.FZ_RESTful_Services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

import au.edu.unsw.soacourse.FZ_RESTful_Services.model.DB_PaymentBean;

public enum DB_PaymentsDao {

	instance;
	private String dbPath = "jdbc:sqlite:"
			+ this.getClass().getClassLoader().getResource("") + "fzrms.db";
	private String xmlPath = this.getClass().getResource("Database.xml")
			.getPath();
	private static Document doc;
	private static XPath xpath;

	private DB_PaymentsDao() {
		init(xmlPath);
	}

	private static void init(String xmlFilePath) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;

		try {
			db = dbf.newDocumentBuilder();
			doc = db.parse(new FileInputStream(new File(xmlFilePath)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPathFactory factory = XPathFactory.newInstance();
		xpath = factory.newXPath();
	}

	public DB_PaymentBean getPayment(String _pid) {
		DB_PaymentBean returnPayment = new DB_PaymentBean();

		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "SELECT * FROM payments WHERE _pid = '" + _pid + "';";
			Statement stmt = DBconnect.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				returnPayment.set_pid(rs.getString(1));
				returnPayment.set_nid(rs.getString(2));
				returnPayment.setAmount(rs.getString(3));
				returnPayment.setCredit_card_details(rs.getString(4));
				returnPayment.setPaid_date(rs.getString(rs.getString(5)));
			}
		} catch (Exception e) {

		}

		return returnPayment;
	}

	public boolean updatePayment(DB_PaymentBean payment) {

		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "UPDATE payments SET credit_card_details = '"
					+ payment.getCredit_card_details() + "' WHERE _pid = '"
					+ payment.get_pid() + "';";
			Statement stmt = DBconnect.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
		} catch (Exception e) {

		}

		return true;
	}

	public String createPayment(DB_PaymentBean payment) {
		String uri = "http://localhost:8080/FZ_RMS_RESTful_Services/Payments/"
				+ payment.get_pid();

		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "INSERT INTO payments (_pid, _nid, amount) VALUES ('"
					+ payment.get_pid() + "' '" + payment.get_nid() + "' '"
					+ payment.getAmount() + "')";
			Statement stmt = DBconnect.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
		} catch (Exception e) {

		}

		return uri;
	}
}
