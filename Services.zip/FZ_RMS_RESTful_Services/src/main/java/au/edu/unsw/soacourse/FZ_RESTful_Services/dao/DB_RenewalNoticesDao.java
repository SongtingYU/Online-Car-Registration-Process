package au.edu.unsw.soacourse.FZ_RESTful_Services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import au.edu.unsw.soacourse.FZ_RESTful_Services.model.EntryBean;

public enum DB_RenewalNoticesDao {

	instance;
	private String dbPath = "jdbc:sqlite:"
			+ this.getClass().getClassLoader().getResource("") + "fzrms.db";
	private String xmlPath = this.getClass().getResource("Database.xml")
			.getPath();
	private static Document doc;
	private static XPath xpath;

	private DB_RenewalNoticesDao() {
		init(xmlPath);
	}

	private static void init(String xmlFilePath) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;

		try {
			db = dbf.newDocumentBuilder();
			doc = db.parse(new FileInputStream(new File(xmlFilePath)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPathFactory factory = XPathFactory.newInstance();
		xpath = factory.newXPath();
	}
	

	public List<String> generateNotices() {
		List<EntryBean> entrysList = RegistrationsDao.instance
				.getRegistrations();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		Date nowDate = date;
		calendar.add(Calendar.DATE, 30);
		date = calendar.getTime();
		Date upperDate = date;
		
		List<String> uriList = new ArrayList<String>();

		int _nid = 0;
		for (EntryBean entry : entrysList) {
			try {
				Date validDate = df.parse(entry.getregistrationValidTill());

				String _rid = entry.get_rid();

				if (validDate.compareTo(nowDate) != -1
						&& upperDate.compareTo(validDate) != -1) {
					_nid++;
					String urlString = "http://localhost:8080/FZ_RMS_RESTful_Services/RenewalNotices/_nid/" + _nid;
					uriList.add(urlString);
					Class.forName("org.sqlite.JDBC");
					Connection DBconnect = DriverManager.getConnection(dbPath);
					String sql = "INSERT INTO notices (_nid, _rid, status) VALUES ('"
							+ String.valueOf(_nid)
							+ "', '"
							+ _rid
							+ "', 'created');";
					Statement stmt = DBconnect.createStatement();
					stmt.executeQuery(sql);
				}

			} catch (Exception e) {

			}
		}

		return uriList;
	}
	
	public Boolean CancelledRequest(String _nid) {
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "UPDATE notices SET status = 'archived' WHERE _nid = '" + _nid + "';";
			Statement stmt = DBconnect.createStatement();
			stmt.executeQuery(sql);
		} catch (Exception e) {
			
		}
		
		return true;
	}
	
	public EntryBean getNotice(String _nid) {
		EntryBean tmpBean = new EntryBean();
		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "SELECT _rid FROM notices WHERE _nid = '" + _nid
					+ "';";
			Statement stmt = DBconnect.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				return RegistrationsDao.instance.queryEntry(rs.getString(1));
			}
		} catch (Exception e) {

		}
		return tmpBean;
	}
	
	public boolean updateEntry(String _nid, String user, EntryBean entry) {
		String _rid = "";
		String status = "";
		try {
			Class.forName("org.sqlite.JDBC");
			Connection DBconnect = DriverManager.getConnection(dbPath);
			String sql = "SELECT * FROM notices WHERE _nid = '" + _nid
					+ "';";
			Statement stmt = DBconnect.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				_rid = rs.getString(2);
				status = rs.getString(3);
			}
		} catch (Exception e) {

		}
		
		if (status.equals(user)) return false;
		
		entry.set_rid(_rid);
		
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate(
					"Registrations/child::Entry[_rid='" + entry.get_rid()
							+ "']", doc, XPathConstants.NODESET);
			if (nodeList.getLength() == 0)
				return false;
			Element n = (Element) nodeList.item(0);
			for (Map.Entry<String, String> a : entry.getMap().entrySet()) {
				String key = CapsName(a.getKey());
				String value = a.getValue();
				if (!"$".equals(value)) {
					n.getElementsByTagName(key).item(0).setTextContent(value);
				} else {
					Element e = (Element) n.getElementsByTagName(key).item(0);
					for (Map.Entry<String, String> b : entry.getDriver()
							.getMap().entrySet()) {
						String key1 = CapsName(b.getKey());
						String value1 = b.getValue();
						e.getElementsByTagName(key1).item(0)
								.setTextContent(value1);
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
			return false;
		}
		rewriteToXml();
		return true;
	}
	
	private String CapsName(String name) {
		char[] cs = name.toCharArray();
		cs[0] -= cs[0] > 96 && cs[0] < 123 ? 32 : 0;
		return String.valueOf(cs);
	}

	private void rewriteToXml() {
		TransformerFactory tFactory = TransformerFactory.newInstance();
		try {
			Transformer transformer = tFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new java.io.File(xmlPath));
			transformer.transform(source, result);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
