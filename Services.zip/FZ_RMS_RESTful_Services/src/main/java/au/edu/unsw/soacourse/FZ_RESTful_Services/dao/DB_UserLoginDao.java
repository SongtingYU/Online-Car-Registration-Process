package au.edu.unsw.soacourse.FZ_RESTful_Services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import au.edu.unsw.soacourse.FZ_RESTful_Services.model.EntryBean;

public enum DB_UserLoginDao {

	instance;
	private String dbPath = "jdbc:sqlite:"
			+ this.getClass().getClassLoader().getResource("") + "fzrms.db";
	private String xmlPath = this.getClass().getResource("Database.xml")
			.getPath();
	private static Document doc;
	private static XPath xpath;

	private DB_UserLoginDao() {
		init(xmlPath);
	}

	private static void init(String xmlFilePath) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;

		try {
			db = dbf.newDocumentBuilder();
			doc = db.parse(new FileInputStream(new File(xmlFilePath)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPathFactory factory = XPathFactory.newInstance();
		xpath = factory.newXPath();
	}

	public EntryBean queryEntry(String _rid) {
		EntryBean result = null;
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate(
					"Registrations/child::Entry[_rid='" + _rid + "']", doc,
					XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		try {
			for (int i = 0; i < nodeList.getLength(); i++) {
				JAXBContext jaxbContexts;
				jaxbContexts = JAXBContext.newInstance(EntryBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContexts
						.createUnmarshaller();

				EntryBean entry = (EntryBean) jaxbUnmarshaller
						.unmarshal(nodeList.item(i));
				result = entry;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		return result;
	}


}
