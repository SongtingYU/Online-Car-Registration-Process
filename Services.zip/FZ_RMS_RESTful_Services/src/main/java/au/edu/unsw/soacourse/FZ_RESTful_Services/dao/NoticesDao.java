package au.edu.unsw.soacourse.FZ_RESTful_Services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import au.edu.unsw.soacourse.FZ_RESTful_Services.model.*;

public enum NoticesDao {

	instance;
	private String NotXmlPath = this.getClass().getResource("Notices.xml")
			.getPath();
	private static Document NotDoc;
	private static XPath xpath;

	private NoticesDao() {
		init(NotXmlPath);
	}

	private static void init(String NotXmlPath) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;

		try {
			db = dbf.newDocumentBuilder();
			NotDoc = db.parse(new FileInputStream(new File(NotXmlPath)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPathFactory factory = XPathFactory.newInstance();
		xpath = factory.newXPath();
	}

	public NoticeBean getNotice(String _nid) {
		NoticeBean result = null;
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("notices/child::notice[_nid='"
					+ _nid + "']", NotDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		try {
			for (int i = 0; i < nodeList.getLength(); i++) {
				JAXBContext jaxbContexts;
				jaxbContexts = JAXBContext.newInstance(NoticeBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContexts
						.createUnmarshaller();

				NoticeBean notice = (NoticeBean) jaxbUnmarshaller
						.unmarshal(nodeList.item(i));
				result = notice;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		return result;
	}

	public List<NoticeBean> getAllNotices() {
		List<NoticeBean> results = new ArrayList<NoticeBean>();
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("notices/child::notice",
					NotDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		try {
			for (int i = 0; i < nodeList.getLength(); i++) {
				JAXBContext jaxbContexts;
				jaxbContexts = JAXBContext.newInstance(NoticeBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContexts
						.createUnmarshaller();

				NoticeBean notice = (NoticeBean) jaxbUnmarshaller
						.unmarshal(nodeList.item(i));
				results.add(notice);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		return results;
	}

	public String insertNotice(NoticeBean notice) {
		String _nid = count_nid();
		notice.set_nid(_nid);

		Element root = NotDoc.getDocumentElement();
		Element u = NotDoc.createElement("notice");
		root.appendChild(u);
		for (Map.Entry<String, String> a : notice.getMap().entrySet()) {
			String key = a.getKey();
			String value = a.getValue();

			Element k = NotDoc.createElement(key);
			k.appendChild(NotDoc.createTextNode(value));
			u.appendChild(k);
		}
		rewriteToXml();
		return _nid;
	}

	public String updateNotice(NoticeBean notice) {
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("notices/child::notice[_nid='"
					+ notice.get_nid() + "']", NotDoc, XPathConstants.NODESET);
			if (nodeList.getLength() == 0)
				return "UPDATENOTFOUND";
			Element n = (Element) nodeList.item(0);
			for (Map.Entry<String, String> a : notice.getMap().entrySet()) {
				String key = a.getKey();
				String value = a.getValue();
				if (!value.isEmpty() && !("".equals(value))) {
					n.getElementsByTagName(key).item(0).setTextContent(value);
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		rewriteToXml();
		return notice.get_nid();
	}

	public String count_nid() {
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("notices/child::notice",
					NotDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}

		return String.format("%03d", nodeList.getLength() + 1);
	}

	private void rewriteToXml() {
		TransformerFactory tFactory = TransformerFactory.newInstance();
		try {
			Transformer transformer = tFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(NotDoc);
			StreamResult result = new StreamResult(new java.io.File(NotXmlPath));
			transformer.transform(source, result);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<NoticeBean> generateNotices() {
		List<EntryBean> entrysList = RegistrationsDao.instance
				.getRegistrations();
		List<NoticeBean> returnNoticesList = new ArrayList<NoticeBean>();
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		Date nowDate = date;
		calendar.add(Calendar.DATE, 30);
		date = calendar.getTime();
		Date upperDate = date;

		List<String> uriList = new ArrayList<String>();
		for (EntryBean entry : entrysList) {
			Date validDate = null;
			try {
				validDate = df.parse(entry.getregistrationValidTill());
			} catch (ParseException e) {
				e.printStackTrace();
			}

			Boolean insertflag = true;
			for (NoticeBean tmp : getAllNotices()) {
				if (tmp.get_rid().equals(entry.get_rid())) {
					insertflag = false;
					break;
				}
			}

			if (insertflag && validDate.compareTo(nowDate) != -1
					&& upperDate.compareTo(validDate) != -1) {
				String uriString = "http://localhost:8080/FZ_RMS_RESTful_Services/Notices/";
				NoticeBean newNotice = new NoticeBean();
				newNotice.set_rid(entry.get_rid());
				newNotice.setStatus("created");
				String _nid = insertNotice(newNotice);
				uriString += _nid;
				uriList.add(uriString);
				returnNoticesList.add(getNotice(_nid));
			}
		}

		return returnNoticesList;
	}

	public Boolean updateDriver(String _nid, EntryBean entry) {

		NoticeBean notice = getNotice(_nid);

		if (notice != null && !notice.getStatus().equals("under-review")) {
			if (RegistrationsDao.instance.updateEntry(entry)) {
				notice.setStatus("requested");
				updateNotice(notice);
				return true;
			}
		}

		return false;
	}

	public Boolean updateOfficer(String _nid, String status) {

		if (!status.equals("under-review") && !status.equals("accepted")
				&& !status.equals("rejected")) {
			return false;
		}

		NoticeBean notice = getNotice(_nid);

		if (notice != null) {
			notice.setStatus(status);
			updateNotice(notice);
			return true;
		}

		return false;
	}

	public Boolean CancelledRequest(String _nid) {

		NoticeBean notice = getNotice(_nid);

		if (notice != null) {
			notice.setStatus("cancelled");
			updateNotice(notice);
			return true;
		}

		return false;
	}

	public Boolean ArchivedRequest(String _nid) {

		NoticeBean notice = getNotice(_nid);

		if (notice != null) {
			notice.setStatus("archived");
			updateNotice(notice);
			return true;
		}

		return false;
	}
}
