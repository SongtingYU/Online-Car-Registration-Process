package au.edu.unsw.soacourse.FZ_RESTful_Services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import au.edu.unsw.soacourse.FZ_RESTful_Services.model.PaymentBean;

public enum PaymentsDao {

	instance;
	private String PayXmlPath = this.getClass().getResource("Payments.xml")
			.getPath();
	private static Document PayDoc;
	private static XPath xpath;

	private PaymentsDao() {
		init(PayXmlPath);
	}

	private static void init(String PayXmlPath) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db;

		try {
			db = dbf.newDocumentBuilder();
			PayDoc = db.parse(new FileInputStream(new File(PayXmlPath)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		XPathFactory factory = XPathFactory.newInstance();
		xpath = factory.newXPath();
	}

	public PaymentBean getPayment(String _pid) {
		PaymentBean result = null;
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate(
					"payments/child::payment[_pid='" + _pid + "']", PayDoc,
					XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		try {
			for (int i = 0; i < nodeList.getLength(); i++) {
				JAXBContext jaxbContexts;
				jaxbContexts = JAXBContext.newInstance(PaymentBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContexts
						.createUnmarshaller();

				PaymentBean payment = (PaymentBean) jaxbUnmarshaller
						.unmarshal(nodeList.item(i));
				result = payment;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		return result;
	}

	public List<PaymentBean> getAllPayments() {
		List<PaymentBean> results = new ArrayList<PaymentBean>();
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("payments/child::payment",
					PayDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		try {
			for (int i = 0; i < nodeList.getLength(); i++) {
				JAXBContext jaxbContexts;
				jaxbContexts = JAXBContext.newInstance(PaymentBean.class);
				Unmarshaller jaxbUnmarshaller = jaxbContexts
						.createUnmarshaller();

				PaymentBean payment = (PaymentBean) jaxbUnmarshaller
						.unmarshal(nodeList.item(i));
				results.add(payment);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		return results;
	}

	public String insertPayment(PaymentBean payment) {
		String _pid = count_pid();
		payment.set_pid(_pid);

		Element root = PayDoc.getDocumentElement();
		Element u = PayDoc.createElement("payment");
		root.appendChild(u);
		for (Map.Entry<String, String> a : payment.getMap().entrySet()) {
			String key = a.getKey();
			String value = a.getValue();

			Element k = PayDoc.createElement(key);
			k.appendChild(PayDoc.createTextNode(value.isEmpty() ? "" : value));
			u.appendChild(k);
		}
		rewriteToXml();
		return _pid;
	}

	public String updatePayment(PaymentBean payment) {
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath
					.evaluate(
							"payments/child::payment[_pid='"
									+ payment.get_pid() + "']", PayDoc,
							XPathConstants.NODESET);
			if (nodeList.getLength() == 0)
				return "UPDATENOTFOUND";
			Element n = (Element) nodeList.item(0);
			for (Map.Entry<String, String> a : payment.getMap().entrySet()) {
				String key = a.getKey();
				String value = a.getValue();
				if (key.equals("credit_card_details")) {
					if (!value.isEmpty() && !("".equals(value))) {
						n.getElementsByTagName(key).item(0)
								.setTextContent(value);
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}
		rewriteToXml();
		return payment.get_pid();
	}

	public String count_pid() {
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("payments/child::payment",
					PayDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}

		return nodeList == null ? "001" : String.format("%03d",
				nodeList.getLength() + 1);
	}

	public String last_pid() {
		NodeList nodeList = null;
		try {
			nodeList = (NodeList) xpath.evaluate("payments/child::payment",
					PayDoc, XPathConstants.NODESET);
		} catch (Exception e) {
			System.out.println(e.getMessage() + " " + e.getCause());
		}

		return String.format("%03d", nodeList.getLength());
	}

	private void rewriteToXml() {
		TransformerFactory tFactory = TransformerFactory.newInstance();
		try {
			Transformer transformer = tFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(PayDoc);
			StreamResult result = new StreamResult(new java.io.File(PayXmlPath));
			transformer.transform(source, result);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
