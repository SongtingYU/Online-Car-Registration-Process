package au.edu.unsw.soacourse.FZ_RESTful_Services.model;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "_nid", "_rid", "status" })
@XmlRootElement(name = "notice")
public class NoticeBean {

	private String _nid;
	private String _rid;
	private String status;
	private Map<String, String> map = new LinkedHashMap<String, String>();

	public NoticeBean() {
		super();
	}

	public NoticeBean(String _nid, String _rid, String status) {
		super();
		this._nid = _nid;
		this._rid = _rid;
		this.status = status;
		mapBuild();
	}

	private void mapBuild() {
		map.put("_nid", _nid);
		map.put("_rid", _rid);
		map.put("status", status);
	}

	public String get_nid() {
		return _nid;
	}
	
	@XmlElement(name = "_nid")
	public void set_nid(String _nid) {
		this._nid = _nid;
		mapBuild();
	}

	public String get_rid() {
		return _rid;
	}

	@XmlElement(name = "_rid")
	public void set_rid(String _rid) {
		this._rid = _rid;
		mapBuild();
	}

	public String getStatus() {
		return status;
	}

	@XmlElement(name = "status")
	public void setStatus(String status) {
		this.status = status;
		mapBuild();
	}

	public Map<String, String> getMap() {
		return map;
	}

}
