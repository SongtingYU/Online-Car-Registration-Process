package au.edu.unsw.soacourse.FZ_RESTful_Services.model;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "_pid", "_nid", "amount", "credit_card_details",
		"paid_date" })
@XmlRootElement(name = "payment")
public class PaymentBean {

	private String _pid;
	private String _nid;
	private String amount;
	private String credit_card_details;
	private String paid_date;
	private Map<String, String> map = new LinkedHashMap<String, String>();

	public PaymentBean() {
		super();
	}

	public PaymentBean(String _pid, String _nid, String amount,
			String credit_card_details, String paid_date) {
		super();
		this._pid = _pid;
		this._nid = _nid;
		this.amount = amount;
		this.credit_card_details = credit_card_details;
		this.paid_date = paid_date;
		mapBuild();
	}

	private void mapBuild() {
		map.put("_pid", _pid);
		map.put("_nid", _nid);
		map.put("amount", amount);
		map.put("credit_card_details", credit_card_details);
		map.put("paid_date", paid_date);
	}

	public String get_pid() {
		return _pid;
	}

	@XmlElement(name = "_pid")
	public void set_pid(String _pid) {
		this._pid = _pid;
		mapBuild();
	}

	public String get_nid() {
		return _nid;
	}

	@XmlElement(name = "_nid")
	public void set_nid(String _nid) {
		this._nid = _nid;
		mapBuild();
	}

	public String getAmount() {
		return amount;
	}

	@XmlElement(name = "amount")
	public void setAmount(String amount) {
		this.amount = amount;
		mapBuild();
	}

	public String getCredit_card_details() {
		return credit_card_details;
	}

	@XmlElement(name = "credit_card_details")
	public void setCredit_card_details(String credit_card_details) {
		this.credit_card_details = credit_card_details;
		mapBuild();
	}

	public String getPaid_date() {
		return paid_date;
	}

	@XmlElement(name = "paid_date")
	public void setPaid_date(String paid_date) {
		this.paid_date = paid_date;
		mapBuild();
	}

	public Map<String, String> getMap() {
		return map;
	}
}
