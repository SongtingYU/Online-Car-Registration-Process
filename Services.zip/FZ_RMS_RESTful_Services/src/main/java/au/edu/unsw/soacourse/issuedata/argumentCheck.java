package au.edu.unsw.soacourse.issuedata;

public class argumentCheck {
	public static boolean yearCheck(String y1,String y2){
		String regex="^[1|2][0-9]{3}";
		if(y1.matches(regex)&&y2.matches(regex)){
			if(Integer.parseInt(y1)<=Integer.parseInt(y2)){
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean ageRangeCheck(String y1,String y2){
		String regex="^[1-8][0-9]";
		if(y1.matches(regex)&&y2.matches(regex)){
			if(Integer.parseInt(y1)<=Integer.parseInt(y2)){
				return true;
			}
		}
		
		return false;
	}
	
	
	
	public static void main(String args[]){
		System.out.println(argumentCheck.ageRangeCheck("11","22"));
	}
	
}
