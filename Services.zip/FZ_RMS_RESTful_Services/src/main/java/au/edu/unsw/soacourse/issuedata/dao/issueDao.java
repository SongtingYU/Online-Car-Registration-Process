package au.edu.unsw.soacourse.issuedata.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.sql.rowset.spi.XmlReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;
import javax.xml.xquery.XQResultSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;
public class issueDao {
	private String path=this.getClass().getResource("table1.xml").getPath();
	private String path2=this.getClass().getResource("table2.xml").getPath();
	
	public String q1(){
		String query="let $reasons:="
				+"for $reason in distinct-values(doc(\""
				+ path2
				+ "\")/table2/Rowgroup/row/@name)"
				+ "\nwhere $reason!=\"Total\""
				+ "\nreturn"
				+"\n<reason>"
				+"\n{$reason}"
				+"\n</reason>"
				+"\nreturn"
				+"\n<table>"
				+"{$reasons}"
				+"\n</table>"
				;
		return query;
	}
	
	public String q2(){
		String query="let $groups:="
				+"for $group in distinct-values(doc(\""
				+ path
				+ "\")/table1/row/agegroup/*/name())"
				+ "\nreturn"
				+ "\n<group>"
				+ "\n{$group}"
				+ "\n</group>"
				+"\nreturn"
				+"\n<table>"
				+"\n{$groups}"
				+"\n</table>";
		return query;
	}
	public String q3(String arg1){
		
		String query="let $regex:=\"^"
				+arg1
				+"\""
				+ "\nlet $year:= "
				+ "\nfor $time in doc(\""
				+ path
				+ "\")/table1/row"
						+ "\nwhere matches($time/@name, $regex)=true()"
						+ "\nreturn $time"
						+ "\nreturn"
						+ "\n<year name=\""
						+ arg1
						+ "\">"
								+ "\n{$year}"
								+ "\n</year>";
		return query;
	}
	public String q4(String years){
		String regex="";
		String[] l1=years.split("-");
		int from =Integer.parseInt(l1[0]);
		int to=Integer.parseInt(l1[1]);
		for (int i=from;i<=to;i++){
			regex+="^"+String.valueOf(i)+"|";
		}
		regex=regex.substring(0, regex.length()-1);
		
		String query="let $regex:=\""
				+ regex
				+"\""
				+ "\nlet $year:= "
				+ "\nfor $time in doc(\""
				+ path
				+ "\")/table1/row"
						+ "\nwhere matches($time/@name, $regex)=true()"
						+ "\nreturn $time"
						+ "\nreturn"
						+ "\n<year name=\""
						+ years
						+ "\">"
						+ "\n{$year}"
						+ "\n</year>";
			
		
		return query;	
	}
	public String q5(String arg1,String arg2){
		String regex="";
		String[] l1=arg1.split("-");
		int from =Integer.parseInt(l1[0]);
		int to=Integer.parseInt(l1[1]);
		for (int i=from;i<=to;i++){
			regex+="^"+String.valueOf(i)+"|";
		}
		regex=regex.substring(0, regex.length()-1);
		
		String[] l2=arg2.split("-");
		int from2 =Integer.parseInt(l2[0]);
		int to2=Integer.parseInt(l2[1]);
		
		String range="";
		for(int i=from2;i<=to2;i++){
			if(i>=16 &&i<=17){
				range+="\n{$row/Age16-17}";
				i=17;
				continue;
			}
			if(i>=18 &&i<=25){
				range+="\n{$row/Age18-25}";
				i=25;
				continue;
			}
			if(i>=26 &&i<=29){
				range+="\n{$row/Age26-29}";
				i=29;
				continue;
			}
			if(i>=30 &&i<=39){
				range+="\n{$row/Age30-39}";
				i=39;
				continue;
			}
			if(i>=40 &&i<=49){
				range+="\n{$row/Age40-49}";
				i=49;
				continue;
			}
			if(i>=50 &&i<=59){
				range+="\n{$row/Age50-59}";
				i=59;
				continue;
			}
			if(i>=60 &&i<=69){
				range+="\n{$row/Age60-69}";
				i=69;
				continue;
			}
			if(i>=70 &&i<=79){
				range+="\n{$row/Age70-79}";
				i=79;
				continue;
			}
			if(i>=80){
				range+="\n{$row/Above80}";
				i=to2;
				continue;
			}
		}
		
		
		
		String query="let $regex:=\""
				+ regex
				+ "\""
				+ "\nlet $doc:=doc(\""
				+ path2
				+ "\")"
				+"let $months:="
				+ "\nfor $time in $doc/table2/Rowgroup"
				+ "\nwhere matches($time/@name, $regex)=true()"
				+ "\nreturn"
				+ "\n<Rowgroup name=\"{$time/@name}\">"
						+ "\n{for $row in $time/row"
						+ "\nreturn"
						+ "\n<row name=\"{$row/@name}\">"
						+ range
						+ "\n</row>"
						+ "\n}"
						+"\n</Rowgroup>"
				+"\nreturn"		
				+"<table>"
				+"{$months}"
				+"</table>";
		return query;
	}
	
	public String getReasons() throws XQException{
//		InputStream inputStream = new FileInputStream(new File("books.xqy"));
		String res="";
	      XQDataSource ds = new SaxonXQDataSource();
	      
	      XQConnection conn = ds.getConnection();
	      XQPreparedExpression exp = conn.prepareExpression(q1());
	      XQResultSequence result = exp.executeQuery();
	      
	      
//	      System.out.println(result.getSequenceAsString(null));
	      
	      res=result.getSequenceAsString(null);
		return res;
	   }
	
	public String getAgeGroups() throws XQException{
		String res="";
	      XQDataSource ds = new SaxonXQDataSource();
	      
	      XQConnection conn = ds.getConnection();
	      XQPreparedExpression exp = conn.prepareExpression(q2());
	      XQResultSequence result = exp.executeQuery();
	     
	      res=result.getSequenceAsString(null);
		return res;
	}
	
	public String getOIByYear(String year) throws XQException{
		String res="";
	      XQDataSource ds = new SaxonXQDataSource();
	      
	      XQConnection conn = ds.getConnection();
	      XQPreparedExpression exp = conn.prepareExpression(q3(year));
	      XQResultSequence result = exp.executeQuery();
	     
	      res=result.getSequenceAsString(null);
		return res;
	}
	
	public String getOIByYears(String year) throws XQException{
		String res="";
	      XQDataSource ds = new SaxonXQDataSource();
	      
	      XQConnection conn = ds.getConnection();
	      XQPreparedExpression exp = conn.prepareExpression(q4(year));
	      XQResultSequence result = exp.executeQuery();
	     
	      res=result.getSequenceAsString(null);
		return res;
	}
	public String getRpByYearsGroup(String years,String ages) throws XQException{
		String res="";
	      XQDataSource ds = new SaxonXQDataSource();
	      
	      XQConnection conn = ds.getConnection();
	      XQPreparedExpression exp = conn.prepareExpression(q5(years,ages));
	      XQResultSequence result = exp.executeQuery();
	     
	      res=result.getSequenceAsString(null);
		return res;
	}
	
	public static void main(String args[]) throws FileNotFoundException, XQException{
		issueDao test=new issueDao();
//		System.out.println(q4("2009-1010"));
		System.out.println(test.q5("2009-2011","17-18"));
		System.out.println(test.getRpByYearsGroup("2009-2011","17-18"));
//		System.out.println(getRpByYearsGroup("2009-2011","25-16"));
	}
}
