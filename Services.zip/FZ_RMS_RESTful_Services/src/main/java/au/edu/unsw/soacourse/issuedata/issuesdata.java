package au.edu.unsw.soacourse.issuedata;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.xquery.XQException;

import au.edu.unsw.soacourse.issuedata.dao.issueDao;


@Path("/registrationDS")
public class issuesdata {
	private issueDao issuedao=new issueDao();
	@GET
	@Path("reasons")
	@Produces(MediaType.TEXT_PLAIN)
	public String ListReasons() {
		String res = "";
			try {
				res = issuedao.getReasons();
			} catch (XQException e) {
				e.printStackTrace();
			}
		return res;
	}
	
	@GET
	@Path("groups")
	@Produces(MediaType.TEXT_PLAIN)
	public String ListGroups() {
		String res = "";
			try {
				res = issuedao.getAgeGroups();
			} catch (XQException e) {
				e.printStackTrace();
			}
		return res;
	}
	
	@GET
	@Path("monthly_issues/opt")
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public String getIssues(@FormParam("year") String year,@FormParam("y1") String y1,@FormParam("y2") String y2) throws XQException{
		String res="";
		if(year != null && y1==null && y2==null && year.matches("^[1|2][0-9]{3}")){
			res=issuedao.getOIByYear(year);
		}
		else if(y1 != null && y2 != null && year==null&& argumentCheck.yearCheck(y1, y2)){
			res=issuedao.getOIByYears(y1+"-"+y2);
		}
		else{
			res="invalid parameters passed";
		}
		return res;	
	}
	
	@GET
	@Path("monthly_replacements/opt")
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public String getIssuesYearAgeRange(@FormParam("y1") String y1,@FormParam("y2") String y2,@FormParam("a1") String a1,@FormParam("a2") String a2) throws XQException{
		String res="";
		if(y1 != null && y2!=null&& a1!=null && a2!=null && argumentCheck.yearCheck(y1, y2) || !argumentCheck.ageRangeCheck(a1, a2)){
			res=issuedao.getRpByYearsGroup(y1+"-"+y2, a1+"-"+a2);
		}
		else{
			res="ivalid range of year or age passed!";
		}	
		return res;	
	}
	
}
