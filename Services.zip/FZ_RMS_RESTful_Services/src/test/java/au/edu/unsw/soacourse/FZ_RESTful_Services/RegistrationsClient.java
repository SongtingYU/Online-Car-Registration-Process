package au.edu.unsw.soacourse.FZ_RESTful_Services;

import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.client.WebClient;


public class RegistrationsClient {

	static final String REST_URI = "http://localhost:8080/FZ_RMS_RESTful_Services";

	public static void main(String[] args) {

		WebClient RegistrationsClient = WebClient.create(REST_URI);
		String s = "";

		// Get all Registrations
		RegistrationsClient.path("/Registrations").accept(
				MediaType.APPLICATION_XML);
		s = RegistrationsClient.get(String.class);
		System.out.println("Get all RegistrationsClient --");
		System.out.println(s);
		System.out.println();

		// Get Entry 001 (current path is /Registrations, go to
		// /Registrations/001)
		RegistrationsClient.path("/001").accept(MediaType.APPLICATION_XML);
		s = RegistrationsClient.get(String.class);
		System.out.println("Get Entry 001 --");
		System.out.println(s);
		System.out.println();

	}

}
